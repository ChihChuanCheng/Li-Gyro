
// Arm extension 

goog.provide('Blockly.Arduino.arm');

Blockly.Arduino.wifi_softap_wait_until_ready = function(){
  var ssid = Blockly.Arduino.valueToCode(this, 'SSID', Blockly.Arduino.ORDER_ATOMIC) || ''
  var password = Blockly.Arduino.valueToCode(this, 'PASSWORD', Blockly.Arduino.ORDER_ATOMIC) || ''
  ssid = ssid.replace(/\"/g, "");
  password = password.replace(/\"/g, "");

  Blockly.Arduino.definitions_['define_softap_wifi_include'] = '#include <ESP8266WiFi.h>';
  Blockly.Arduino.definitions_['define_softap_wifi_ssid'] = 'char _softap_ssid[] = "' + ssid + '";';
  Blockly.Arduino.definitions_['define_softap_wifi_pass'] = 'char _softap_pass[] = "' + password + '";';

  var code = 'WiFi.softAP(_softap_ssid,_softap_pass);\n';

  return code;
};

Blockly.Arduino.ligyro_motor_init = function(){

  Blockly.Arduino.definitions_['define_left_motor'] = '#define LEFT_MOTOR 4\n';
  Blockly.Arduino.definitions_['define_right_motor'] = '#define RIGHT_MOTOR 5\n';
  
  Blockly.Arduino.definitions_['init_arduino_setup'] = 
	'#include "Arduino.h"\n';

  Blockly.Arduino.setups_['setup_left_motor_pin'] = 'pinMode (LEFT_MOTOR, OUTPUT);'
  Blockly.Arduino.setups_['setup_right_motor_pin'] = 'pinMode (RIGHT_MOTOR, OUTPUT);'
  code ='analogWrite (LEFT_MOTOR,0);\n' +
        'analogWrite (RIGHT_MOTOR,0);\n' +
		'analogWriteRange(255);\n';
  return code;
};

Blockly.Arduino.ligyro_servo_init = function(){

  Blockly.Arduino.definitions_['include_servo_header'] = '#include <Servo.h>\n';
  Blockly.Arduino.definitions_['define_rudder_pin'] = '#define RUDDER 12\n';
  Blockly.Arduino.definitions_['define_elevator_pin'] = '#define ELEVATOR 13\n';
  Blockly.Arduino.definitions_['declare_rudder_servo'] = 'Servo servoRUDDER;\n';
  Blockly.Arduino.definitions_['declare_elevator_servo'] = 'Servo servoELEVATOR;\n';

  Blockly.Arduino.setups_['setup_rudder_pin'] = 'servoRUDDER.attach(RUDDER);'
  Blockly.Arduino.setups_['setup_elevator_pin'] = 'servoELEVATOR.attach(ELEVATOR);'
  code ='servoRUDDER.write(90);\n' +
        'servoELEVATOR.write(90);\n';
  return code;
};

Blockly.Arduino.ligyro_udp_init = function(){

  Blockly.Arduino.definitions_['init_udp_setup'] = 
	'#include <WiFiUdp.h>\n' +
	'WiFiUDP Udp;\n';

  Blockly.Arduino.definitions_['init_v7rc_command_buffer'] = 
	'char packetBuffer[255];\n' +
	'int datafromV7RC[8]={1500,1500,1500,1500,1500,1500,1500,1500};\n';

  code ='Udp.begin(6188);\n';
  return code;
};

Blockly.Arduino.v7rc_wifi_tank_command = function(){

    var code_a = Blockly.Arduino.statementToCode(this,"DO");
	
	Blockly.Arduino.definitions_['init_v7rc_command_receipt_status'] = 
	'bool hasCommand = false;\n';

    Blockly.Arduino.definitions_['v7rc_command_bound'] = 
    'uint8_t commandMapping(int x, int lowerest_input, int highest_input, int lowerbound, int upperbound) {\n' +
    '    return map(x, lowerest_input, highest_input, lowerbound, upperbound) < lowerbound?\n' +
    '        lowerbound:\n' +
    '        map(x, lowerest_input, highest_input, lowerbound, upperbound) > upperbound?\n' +
    '        upperbound:\n' +
    '        map(x, lowerest_input, highest_input, lowerbound, upperbound);\n' +
    '}\n';

    Blockly.Arduino.definitions_['get_v7rc_command'] = 	
	'bool getRadioCommand() {\n' +
	'  int packetSize = Udp.parsePacket();\n' +
	'  if (packetSize) {\n' +
    '    String rxData;\n' +
    '    String data;\n' +
	'    int len = Udp.read(packetBuffer, 255);\n' +
    '    if (len > 0) packetBuffer[len-1] = 0;\n' +
	'    if (len > 0) {\n' +
    '      for (int i = 0; i < len; i++){\n' +
    '        rxData+=packetBuffer[i];\n' +
    '      }\n' +
    '    }\n' +
	'    if(packetBuffer[1]==\'R\'){\n' +
    '      for(int i=0;i<4;i++){\n' +
    '        data = rxData.substring(i*4+3, i*4+7);\n' +
    '        datafromV7RC[i] = data.toInt();\n' +
    '      }\n' +
    '    }\n' +
	'    hasCommand = true;\n' +
	'  } else {\n'+
	'    hasCommand = false;\n' +
	'  }\n' +
    '  return hasCommand;\n' +
    '}\n';

	code =
	'if (0 == WiFi.softAPgetStationNum()) {\n' +
	'  servoRUDDER.write(90);\n' +
	'  servoELEVATOR.write(90);\n' +
	'  analogWrite(LEFT_MOTOR, 0);\n' +
	'  analogWrite(RIGHT_MOTOR, 0);\n' +
	'} else {\n' +
	'  hasCommand = getRadioCommand();\n' +
	'  if (true == hasCommand) {\n' +
	'  '+code_a+'\n' +
	'  }\n' +
	'}\n';
	
  return code;
};

Blockly.Arduino.set_left_motor = function(){

  var lmotor = Blockly.Arduino.valueToCode(this, 'lmotor', Blockly.Arduino.ORDER_ATOMIC) || 0;

  var code = '  analogWrite(LEFT_MOTOR,commandMapping('+ lmotor + ',1000,2000,0,255));\n ';
  return code;
};

Blockly.Arduino.set_right_motor = function(){

  var rmotor = Blockly.Arduino.valueToCode(this, 'rmotor', Blockly.Arduino.ORDER_ATOMIC) || 0;

  var code = '  analogWrite(RIGHT_MOTOR,commandMapping('+ rmotor + ',1000,2000,0,255));\n ';
  return code;
};

Blockly.Arduino.set_rudder = function(){

  var rudder = Blockly.Arduino.valueToCode(this, 'rudder', Blockly.Arduino.ORDER_ATOMIC) || 0;

  var code = '  servoRUDDER.write(commandMapping('+ rudder + ',1000,2000,0,180));\n ';
  return code;
};

Blockly.Arduino.set_elevator = function(){

  var elevator = Blockly.Arduino.valueToCode(this, 'elevator', Blockly.Arduino.ORDER_ATOMIC) || 0;

  var code = '  servoELEVATOR.write(commandMapping('+ elevator + ',1000,2000,0,180));\n ';
  return code;
};

Blockly.Arduino.ligyro_pid_ctrl = function(){

  var desire_throttle = Blockly.Arduino.valueToCode(this, 'desire_throttle', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var desire_yaw = Blockly.Arduino.valueToCode(this, 'desire_yaw', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var wright_yaw = Blockly.Arduino.valueToCode(this, 'wright_yaw', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var yaw_p = Blockly.Arduino.valueToCode(this, 'yaw_p', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var yaw_i = Blockly.Arduino.valueToCode(this, 'yaw_i', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var yaw_d = Blockly.Arduino.valueToCode(this, 'yaw_d', Blockly.Arduino.ORDER_ATOMIC) || 0;
  
  Blockly.Arduino.definitions_['set_pid_parameter'] = 
    'float thro_des, yaw_des;\n' +
	'float error_yaw, error_yaw_prev, integral_yaw, integral_yaw_prev, derivative_yaw, yaw_PID = 0;\n' +
	'float i_limit = 25.0;  // Integrator saturation level, mostly for safety (default 25.0)\n' +
	'float maxYaw = 160;    // Max yaw rate in deg/sec\n' +
	'float dt, current_time, prev_time;\n' +
	'float m1_command_scaled, m2_command_scaled;\n' +
    'int m1_command_PWM, m2_command_PWM;\n' +
	'float Kp_yaw = ' +yaw_p+ ';\n' +
	'float Ki_yaw = ' +yaw_i+ ';\n' +
	'float Kd_yaw = ' +yaw_d+ ';\n';
  
  Blockly.Arduino.definitions_['set_bound'] = 
    'float setBound(float x, float lower, float upper) {\n' +
    '  if (x < lower) {\n' +
    '    return lower;\n' +
    '  }\n' +
    '  else if (x > upper) {\n' +
    '    return upper;\n' +
    '  } else {\n' +
    '    return x;\n' +
    '  }\n' +
    '}\n';
  
  Blockly.Arduino.definitions_['set_desire_state'] = 
	'void getDesState() {\n' +
    '  thro_des = ('+desire_throttle+' - 1000.0)/1000.0; //between 0 and 1\n' +
    '  yaw_des = ('+desire_yaw+' - 1500.0)/500.0;   //between -1 and 1\n' +
    '  thro_des = setBound(thro_des, 0.0, 1.0);             //between 0 and 1\n' +
    '  yaw_des = setBound(yaw_des, -0.5, 0.5)*maxYaw;       //Between -maxYaw and +maxYaw\n' +
    '  if (thro_des < 0.1) {\n' +
    '    yaw_des = yaw_des * 2;\n' +
    '  }\n' +
    '};\n';

  Blockly.Arduino.definitions_['ctrl_angle'] = 
    'void controlANGLE() {\n' +
    '  error_yaw = yaw_des - '+wright_yaw+';\n' +
    '  integral_yaw = integral_yaw_prev + error_yaw*dt;\n' +
    '  if ('+desire_throttle+' < 1060) {   //Don\'t let integrator build if throttle is too low\n' +
	'    integral_yaw = 0;\n' +
    '  }\n' +
    '  integral_yaw = setBound(integral_yaw, -i_limit, i_limit); //Saturate integrator to prevent unsafe buildup\n' +
    '  derivative_yaw = (error_yaw - error_yaw_prev)/dt;\n' +
    '  yaw_PID = .01*(Kp_yaw*error_yaw + Ki_yaw*integral_yaw + Kd_yaw*derivative_yaw); //Scaled by .01 to bring within -1 to 1 range\n' +
    '  error_yaw_prev = error_yaw;\n' +
    '  integral_yaw_prev = integral_yaw;\n' +
    '}\n';

  Blockly.Arduino.definitions_['control_mixer'] = 
    'void controlMixer() {\n' +
    '  float yaw_weight = 0.2;\n' +
    '  m1_command_scaled = thro_des+yaw_weight*(yaw_des/maxYaw)+yaw_PID;\n' +
    '  m2_command_scaled = thro_des-yaw_weight*(yaw_des/maxYaw)-yaw_PID;\n' +
    '}\n';

  Blockly.Arduino.definitions_['scale_commands'] = 
    'void scaleCommands() {\n' +
	'  m1_command_PWM = m1_command_scaled*255;\n' +
    '  m1_command_PWM = setBound(m1_command_PWM, 0, 255);\n' +
	'  m2_command_PWM = m2_command_scaled*255;\n' +
    '  m2_command_PWM = setBound(m2_command_PWM, 0, 255);\n' +
	'}\n';

  Blockly.Arduino.definitions_['loop_rate'] = 
    'void loopRate(int freq) {\n' +
    '  float invFreq = 1.0 / freq;\n' +
    '  unsigned long checker = millis();\n' +
    '  while (invFreq > (checker - current_time)) {\n' +
    '    checker = millis();\n' +
    '  }\n' +
    '}\n';

  var code = 
    '  prev_time = current_time;\n' +  
    '  current_time = millis();\n' +
    '  dt = (current_time - prev_time)/1000.0;' +
	'  datafromV7RC[3] = (2000 - datafromV7RC[3]) + 1000;\n' +
	'  getDesState();\n' +
	'  controlANGLE();\n' +
	'  controlMixer();\n' +
	'  scaleCommands();\n' +
	'  if ((datafromV7RC[1] > 1060) ||\n' +
    '      (datafromV7RC[3] > 1560) ||\n' +
    '      (datafromV7RC[3] < 1440)) {\n' +
	'    analogWrite (LEFT_MOTOR,m1_command_PWM);\n' +
    '    analogWrite (RIGHT_MOTOR,m2_command_PWM);\n' +
	'  } else {\n' +
	'    analogWrite (LEFT_MOTOR,0);\n' +
    '    analogWrite (RIGHT_MOTOR,0);\n' +
	'  }\n' +
	'  loopRate(10);';
  return code;
};

Blockly.Arduino.ligyro_hover_pid_ctrl = function(){

  var desire_throttle = Blockly.Arduino.valueToCode(this, 'desire_throttle', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var desire_forward_backward = Blockly.Arduino.valueToCode(this, 'desire_forward_backward', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var desire_direction = Blockly.Arduino.valueToCode(this, 'desire_direction', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var wright_yaw = Blockly.Arduino.valueToCode(this, 'wright_yaw', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var yaw_p = Blockly.Arduino.valueToCode(this, 'yaw_p', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var yaw_i = Blockly.Arduino.valueToCode(this, 'yaw_i', Blockly.Arduino.ORDER_ATOMIC) || 0;
  var yaw_d = Blockly.Arduino.valueToCode(this, 'yaw_d', Blockly.Arduino.ORDER_ATOMIC) || 0;
  
  Blockly.Arduino.definitions_['set_pid_parameter'] = 
    'float thro_des, pitch_des, yaw_des;\n' +
	'float error_pitch, error_pitch_prev, pitch_des_prev, integral_pitch, integral_pitch_il, integral_pitch_ol, integral_pitch_prev, integral_pitch_prev_il, integral_pitch_prev_ol, derivative_pitch, pitch_PID = 0;\n' +
	'float error_yaw, error_yaw_prev, integral_yaw, integral_yaw_prev, derivative_yaw, yaw_PID = 0;\n' +
	'float i_limit = 25.0; // Integrator saturation level, mostly for safety (default 25.0)\n' +
	'float maxYaw = 160; // Max yaw rate in deg/sec\n' +
	'float maxPitch = 50.0; //Max pitch angle in degrees for angle mode (maximum 60 degrees), deg/sec for rate mode\n' +
	'float dt, current_time, prev_time;\n' +
	'float m1_command_scaled, m2_command_scaled;\n' +
    'int m1_command_PWM, m2_command_PWM;\n' +
	'float s1_command_scaled, s2_command_scaled;\n' +
    'int s1_command_PWM, s2_command_PWM;\n' +
	'float Kp_yaw = ' +yaw_p+ ';\n' +
	'float Ki_yaw = ' +yaw_i+ ';\n' +
	'float Kd_yaw = ' +yaw_d+ ';\n';
  
  Blockly.Arduino.definitions_['set_bound'] = 
    'float setBound(float x, float lower, float upper) {\n' +
    '  if (x < lower) {\n' +
    '    return lower;\n' +
    '  }\n' +
    '  else if (x > upper) {\n' +
    '    return upper;\n' +
    '  } else {\n' +
    '    return x;\n' +
    '  }\n' +
    '}\n';
  
  Blockly.Arduino.definitions_['set_desire_state'] = 
	'void getDesState() {\n' +
    '  thro_des = ('+desire_throttle+' - 1000.0)/1000.0; //between 0 and 1\n' +
	'  pitch_des = ('+desire_forward_backward+' - 1500.0) / 500.0; //between -1 and 1\n' +
    '  yaw_des = ('+desire_direction+' - 1500.0)/500.0;   //between -1 and 1\n' +
    '  thro_des = setBound(thro_des, 0.0, 1.0);             //between 0 and 1\n' +
	'  pitch_des = setBound(pitch_des, -1.0, 1.0) * maxPitch; //between -maxPitch and +maxPitch\n' +
    '  yaw_des = setBound(yaw_des, -0.5, 0.5)*maxYaw;       //Between -maxYaw and +maxYaw\n' +
    '  if (thro_des < 0.1) {\n' +
    '    yaw_des = yaw_des * 2;\n' +
    '  }\n' +
    '};\n';

  Blockly.Arduino.definitions_['ctrl_angle'] = 
    'void controlANGLE() {\n' +
    '  error_yaw = yaw_des - '+wright_yaw+';\n' +
    '  integral_yaw = integral_yaw_prev + error_yaw*dt;\n' +
    '  if ('+desire_throttle+' < 1060) {   //Don\'t let integrator build if throttle is too low\n' +
	'    integral_yaw = 0;\n' +
    '  }\n' +
    '  integral_yaw = setBound(integral_yaw, -i_limit, i_limit); //Saturate integrator to prevent unsafe buildup\n' +
    '  derivative_yaw = (error_yaw - error_yaw_prev)/dt;\n' +
    '  yaw_PID = .01*(Kp_yaw*error_yaw + Ki_yaw*integral_yaw + Kd_yaw*derivative_yaw); //Scaled by .01 to bring within -1 to 1 range\n' +
    '  error_yaw_prev = error_yaw;\n' +
    '  integral_yaw_prev = integral_yaw;\n' +
    '}\n';

  Blockly.Arduino.definitions_['control_mixer'] = 
    'void controlMixer() {\n' +
    '  float yaw_weight = 1;\n' +
	'  float pitch_weight = 1;\n' +
	'  if (datafromV7RC[1] > 1060) {\n' +
    '    m1_command_scaled = thro_des;\n' +
    '    m2_command_scaled = thro_des;\n' +
    '  } else {\n' +
    '    m1_command_scaled = 0;\n' +
    '    m2_command_scaled = 0;\n' +
    '  }\n' +
    '  s1_command_scaled = pitch_weight*(pitch_des/maxPitch) - yaw_weight*(yaw_des/maxYaw) - yaw_PID;\n' +
    '  s2_command_scaled = pitch_weight*(pitch_des/maxPitch) + yaw_weight*(yaw_des/maxYaw) + yaw_PID;\n' +
    '}\n';

  Blockly.Arduino.definitions_['scale_commands'] = 
    'void scaleCommands() {\n' +
	'  m1_command_PWM = m1_command_scaled*255;\n' +
    '  m1_command_PWM = setBound(m1_command_PWM, 0, 255);\n' +
	'  m2_command_PWM = m2_command_scaled*255;\n' +
    '  m2_command_PWM = setBound(m2_command_PWM, 0, 255);\n' +
	'  s1_command_PWM = s1_command_scaled * 90 + 90;\n' +
    '  s1_command_PWM = setBound(s1_command_PWM, 0, 180);\n' +
    '  s2_command_PWM = s2_command_scaled * 90 + 90;\n' +
    '  s2_command_PWM = setBound(s2_command_PWM, 0, 180);\n' + 
	'}\n';

  Blockly.Arduino.definitions_['loop_rate'] = 
    'void loopRate(int freq) {\n' +
    '  float invFreq = 1.0 / freq;\n' +
    '  unsigned long checker = millis();\n' +
    '  while (invFreq > (checker - current_time)) {\n' +
    '    checker = millis();\n' +
    '  }\n' +
    '}\n';

  var code = 
    '  prev_time = current_time;\n' +  
    '  current_time = millis();\n' +
    '  dt = (current_time - prev_time)/1000.0;' +
	'  datafromV7RC[3] = (2000 - datafromV7RC[3]) + 1000;\n' +
	'  getDesState();\n' +
	'  controlANGLE();\n' +
	'  controlMixer();\n' +
	'  scaleCommands();\n' +
	'  if ((datafromV7RC[1] > 1060) ||\n' +
    '      (datafromV7RC[3] > 1560) ||\n' +
    '      (datafromV7RC[3] < 1440)) {\n' +
	'    analogWrite (LEFT_MOTOR,m1_command_PWM);\n' +
    '    analogWrite (RIGHT_MOTOR,m2_command_PWM);\n' +
	'    servoRUDDER.write(s1_command_PWM);\n' +
	'    servoELEVATOR.write(s2_command_PWM);\n' +
	'  } else {\n' +
	'    analogWrite (LEFT_MOTOR,0);\n' +
    '    analogWrite (RIGHT_MOTOR,0);\n' +
	'    servoRUDDER.write(s1_command_PWM);\n' +
	'    servoELEVATOR.write(s2_command_PWM);\n' +
	'  }\n' +
	'  loopRate(10);';
  return code;
};

Blockly.Arduino.v7rc_ch1 = function(){
	
  var code = 'datafromV7RC[0]';
	
  return[code,Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.v7rc_ch2 = function(){
	
  var code = 'datafromV7RC[1]';
	
  return[code,Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.v7rc_ch3 = function(){
	
  var code = 'datafromV7RC[2]';
	
  return[code,Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.v7rc_ch4 = function(){
	
  var code = 'datafromV7RC[3]';
	
  return[code,Blockly.Arduino.ORDER_ATOMIC];
};