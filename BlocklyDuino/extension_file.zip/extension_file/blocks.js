// Created by Mason 2022/09/25

// Robot extension 

goog.provide('Blockly.Blocks.arm');

Blockly.Blocks.arm.HUE = 160;

Blockly.Blocks['wifi_softap_wait_until_ready'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField(Blockly.Msg.SOFTAP_TITLE);
	this.appendValueInput("SSID")
      .setCheck("String")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.SOFTAP_SET_WIFI_SSID);
    this.appendValueInput("PASSWORD")
      .setCheck("String")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.SOFTAP_SET_WIFI_PASSWORD);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip(Blockly.Msg.SOFTAP_TOOLTIP);
  }
};

Blockly.Blocks['ligyro_motor_init'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField(Blockly.Msg.LIGYRO_MOTOR_INIT_TITLE);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip(Blockly.Msg.LIGYRO_MOTOR_INIT_TOOLTIP);
  }
};

Blockly.Blocks['ligyro_servo_init'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField(Blockly.Msg.LIGYRO_SERVO_INIT_TITLE);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip(Blockly.Msg.LIGYRO_SERVO_INIT_TOOLTIP);
  }
};

Blockly.Blocks['ligyro_udp_init'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField(Blockly.Msg.LIGYRO_UDP_INIT_TITLE);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip(Blockly.Msg.LIGYRO_UDP_INIT_TOOLTIP);
  }
};

Blockly.Blocks['v7rc_wifi_tank_command'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField("處理 V7RC Wi-Fi 坦克模式發送的資料")
this.appendStatementInput('DO')
    .appendField('do');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip("需放在 Loop 裏");
  }
};

Blockly.Blocks['set_left_motor'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField(Blockly.Msg.SET_LEFT_MOTOR_TITLE)
    this.appendValueInput('lmotor')
      .setCheck('Number')
      .appendField(Blockly.Msg.SET_MOTOR_NO);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip("設定油門");
  }
};

Blockly.Blocks['set_right_motor'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField(Blockly.Msg.SET_RIGHT_MOTOR_TITLE)
    this.appendValueInput('rmotor')
      .setCheck('Number')
      .appendField(Blockly.Msg.SET_MOTOR_NO);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip("設定油門");
  }
};

Blockly.Blocks['set_rudder'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField(Blockly.Msg.SET_RUDDER_TITLE)
    this.appendValueInput('rudder')
      .setCheck('Number')
      .appendField(Blockly.Msg.SET_RUDDER_NO);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip("設定方向舵");
  }
};

Blockly.Blocks['set_elevator'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField(Blockly.Msg.SET_ELEVATOR_TITLE)
    this.appendValueInput('elevator')
      .setCheck('Number')
      .appendField(Blockly.Msg.SET_ELEVATOR_NO);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip("設定升降舵");
  }
};

Blockly.Blocks['v7rc_ch1'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(20);
    this.appendDummyInput()
      .appendField("V7RC CH1");
    this.setOutput(!0, "Number");
    this.setTooltip("Wi-Fi接到的資料");
  }
};

Blockly.Blocks['v7rc_ch2'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(20);
    this.appendDummyInput()
      .appendField("V7RC CH2");
    this.setOutput(true, "Number");
    this.setTooltip("Wi-Fi接到的資料");
  }
};
Blockly.Blocks['v7rc_ch3'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(20);
    this.appendDummyInput()
      .appendField("V7RC CH3");
    this.setOutput(true, "Number");
    this.setTooltip("Wi-Fi接到的資料");
  }
};
Blockly.Blocks['v7rc_ch4'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(20);
    this.appendDummyInput()
      .appendField("V7RC CH4");
    this.setOutput(true, "Number");
    this.setTooltip("Wi-Fi接到的資料");
  }
};

Blockly.Blocks['ligyro_pid_ctrl'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_TITLE);
	this.appendValueInput("desire_throttle")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_DESIRE_THROTTLE);
    this.appendValueInput("desire_yaw")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_DESIRE_YAW);
	this.appendValueInput("wright_yaw")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_WRIGHT_YAW);
	this.appendValueInput("yaw_p")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_YAW_P);
	this.appendValueInput("yaw_i")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_YAW_I);
	this.appendValueInput("yaw_d")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_YAW_D);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip(Blockly.Msg.LIGYRO_PID_CTRL_TOOLTIP);
  }
};

Blockly.Blocks['ligyro_hover_pid_ctrl'] = {
  init: function() {
    this.setHelpUrl(Blockly.Msg.LIGYRO_HELPURL);
    this.setColour(Blockly.Blocks.arm.HUE);
    this.appendDummyInput()
      .appendField(Blockly.Msg.LIGYRO_HOVER_PID_CTRL_TITLE);
	this.appendValueInput("desire_throttle")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_HOVER_PID_CTRL_DESIRE_THROTTLE);
    this.appendValueInput("desire_forward_backward")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_HOVER_PID_CTRL_DESIRE_FORWARD_BACKWARD);
	this.appendValueInput("desire_direction")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_HOVER_PID_CTRL_DESIRE_DIRECTION);
	this.appendValueInput("wright_yaw")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_WRIGHT_YAW);
	this.appendValueInput("yaw_p")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_YAW_P);
	this.appendValueInput("yaw_i")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_YAW_I);
	this.appendValueInput("yaw_d")
      .setCheck("Number")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField(Blockly.Msg.LIGYRO_PID_CTRL_YAW_D);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip(Blockly.Msg.LIGYRO_HOVER_PID_CTRL_TOOLTIP);
  }
};