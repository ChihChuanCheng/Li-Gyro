// Created by Mason 2020/05/15

Blockly.Msg.CATEGORY_BRAINGO = "機器人積木";

Blockly.Msg.CATEGORY_ARM = "機器人";
Blockly.Msg.ARM = "Arm";
Blockly.Msg.ARM_HELPURL = "https://www.facebook.com/mason.chen.1420";

Blockly.Msg.CATEGORY_FLIGHTCONTROLLER = "ESP8266飛控板";

Blockly.Msg.LIGYRO_HELPURL = "https://github.com/ChihChuanCheng/Li-Gyro"
Blockly.Msg.SOFTAP_TITLE = "啟動Wi-Fi SoftAP模式"
Blockly.Msg.SOFTAP_SET_WIFI_SSID = "Wi-Fi ID"
Blockly.Msg.SOFTAP_SET_WIFI_PASSWORD = "Wi-Fi密碼"
Blockly.Msg.SOFTAP_TOOLTIP = "設定Wi-Fi ID/密碼";

Blockly.Msg.LIGYRO_UDP_INIT_TITLE = "初始化V7RC通道"
Blockly.Msg.LIGYRO_UDP_INIT_TOOLTIP = "讀取V7RC通道前要先初始化"

Blockly.Msg.LIGYRO_MOTOR_INIT_TITLE = "初始化左側/右側空心杯馬達"
Blockly.Msg.LIGYRO_MOTOR_INIT_TOOLTIP = "初始化左側/右側空心杯馬達"

Blockly.Msg.LIGYRO_SERVO_INIT_TITLE = "初始化方向舵/升降舵"
Blockly.Msg.LIGYRO_SERVO_INIT_TOOLTIP = "初始化方向舵/升降舵"

Blockly.Msg.SET_LEFT_MOTOR_TITLE = "設定左側空心杯"
Blockly.Msg.SET_MOTOR_NO = "油門";

Blockly.Msg.SET_RIGHT_MOTOR_TITLE = "設定右側空心杯"

Blockly.Msg.SET_RUDDER_TITLE = "設定方向舵"
Blockly.Msg.SET_RUDDER_NO = "方向舵角度"

Blockly.Msg.SET_ELEVATOR_TITLE = "設定升降舵"
Blockly.Msg.SET_ELEVATOR_NO = "升降舵角度"

Blockly.Msg.LIGYRO_PID_CTRL_TITLE = "萊特機自穩控制"
Blockly.Msg.LIGYRO_PID_CTRL_DESIRE_THROTTLE = "玩家油門控制"
Blockly.Msg.LIGYRO_PID_CTRL_DESIRE_YAW = "玩家方向控制"
Blockly.Msg.LIGYRO_PID_CTRL_WRIGHT_YAW = "機體實際方向姿態"
Blockly.Msg.LIGYRO_PID_CTRL_YAW_P = "方向舵P參數"
Blockly.Msg.LIGYRO_PID_CTRL_YAW_I = "方向舵I參數"
Blockly.Msg.LIGYRO_PID_CTRL_YAW_D = "方向舵D參數"
Blockly.Msg.LIGYRO_PID_CTRL_TOOLTIP = "輸入萊特機PID控制相關參數"

Blockly.Msg.LIGYRO_HOVER_PID_CTRL_TITLE = "氣墊船自穩控制"
Blockly.Msg.LIGYRO_HOVER_PID_CTRL_DESIRE_THROTTLE = "玩家油門控制"
Blockly.Msg.LIGYRO_HOVER_PID_CTRL_DESIRE_FORWARD_BACKWARD = "玩家前後控制"
Blockly.Msg.LIGYRO_HOVER_PID_CTRL_DESIRE_DIRECTION = "玩家方向控制"
Blockly.Msg.LIGYRO_HOVER_PID_CTRL_TOOLTIP = "輸入氣墊船PID控制相關參數"





