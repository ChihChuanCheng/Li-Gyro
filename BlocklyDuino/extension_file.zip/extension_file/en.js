// Created by Mason 2020/05/15

Blockly.Msg.CATEGORY_BRAINGO = "Brain Go Blockly";
Blockly.Msg.CATEGORY_BCAR = "Brain GO Car";

Blockly.Msg.BT_PROCESS_TITLE = "BT_process";
Blockly.Msg.BT_PROCESS_TOOLTIP = "BT_process";
Blockly.Msg.HC05_READ_TITLE = "Read_HC05";
Blockly.Msg.HC05_READ_TOOLTIP = "Read_HC05";
Blockly.Msg.BT_VAR_TITLE = "BT_VAR";
Blockly.Msg.BT_VAR_TOOLTIP = "BT_VAR";
Blockly.Msg.BLED_HIGH = "Off";
Blockly.Msg.BLED_LOW = "On";
Blockly.Msg.BUILDINLED_1 = "Set";
Blockly.Msg.BUILDINLED_2 = "LED to";  

Blockly.Msg.BCAR_INIT_TITLE = "Brain GO initial setup";
Blockly.Msg.BCAR_INIT_TOOLTIP = "Setup Brain GO initial pins";
Blockly.Msg.BCAR_HELPURL = "http://phys5.ncue.edu.tw/braingo2019/";  

Blockly.Msg.MOTOR_1 = "Motor:";
Blockly.Msg.MOTOR_2 = "Speed:";  
Blockly.Msg.BCAR_MOTOR_1 = "White Motor"; 
Blockly.Msg.BCAR_MOTOR_2 = "Blue Motor"; 
Blockly.Msg.BCAR_MOTOR_TOOLTIP = "Setting Motor";
Blockly.Msg.BCAR_TEMP_TITLE = "Measure temperature";
Blockly.Msg.BCAR_TEMP_TOOLTIP = "Measure temperature";

Blockly.Msg.BCAR_BUZZER_1 = "Set Buzzer tone";
Blockly.Msg.BCAR_BUZZER_2 = "Beat";  
Blockly.Msg.BCAR_BUZZER_TOOLTIP = "Set Buzzer tone";

Blockly.Msg.BCAR_USONIC_T = "Detect distance";
Blockly.Msg.BCAR_USONIC_1 = "White U-sonic";
Blockly.Msg.BCAR_USONIC_2 = "Blue U-sonic";
Blockly.Msg.BCAR_USONIC_TOOLTIP = "Setting ultrasonic sensor";

Blockly.Msg.BCAR_IR_T = "Sensor status";
Blockly.Msg.BCAR_IR_1 = "Red";
Blockly.Msg.BCAR_IR_2 = "Green";
Blockly.Msg.BCAR_IR_TOOLTIP = "read sensor value";

Blockly.Msg.BCAR_LED_1 = "Red LED";
Blockly.Msg.BCAR_LED_2 = "Yellow ED";
Blockly.Msg.BCAR_LED_3 = "Green LED";
Blockly.Msg.BCAR_LED_TOOLTIP = "Setup build-in LED";

Blockly.Msg.BCAR_DIGITAL_T1 = "Set";
Blockly.Msg.BCAR_DIGITAL_T2 = "as";
Blockly.Msg.BCAR_DIGITAL_2 = "digital 2";
Blockly.Msg.BCAR_DIGITAL_3 = "digital 3";
Blockly.Msg.BCAR_DIGITAL_12 = "digital 12";
Blockly.Msg.BCAR_DIGITAL_13 = "digital 13";
Blockly.Msg.BCAR_DIGITAL_15 = "digital 15";
Blockly.Msg.BCAR_DIGITAL_16 = "digital 16";
Blockly.Msg.BCAR_DIGITAL_9 = "digital 9";
Blockly.Msg.BCAR_DIGITAL_10 = "digital 10";
Blockly.Msg.BCAR_DIGITAL_ON = "on";
Blockly.Msg.BCAR_DIGITAL_OFF = "off";
Blockly.Msg.BCAR_DIGITAL_TOOLTIP = "Setup digital Pins";

Blockly.Msg.BCAR_PCX_ON = "0";
Blockly.Msg.BCAR_PCX_OFF = "1";
Blockly.Msg.BCAR_PCX_TOOLTIP = "Setup digital Pins";

Blockly.Msg.BCAR_ANGLE_T1 = "Set";
Blockly.Msg.BCAR_ANGLE_T2 = "as";
Blockly.Msg.BCAR_ANGLE_1 = "Red Angle adjustment";
Blockly.Msg.BCAR_ANGLE_2 = "Green Angle adjustment";
Blockly.Msg.BCAR_ANGLE_TOOLTIP = "Angle adjustment";

Blockly.Msg.BCAR_BT_READ_T1 = "BT check";
Blockly.Msg.BCAR_BT_READ_T2 = "BT read";
Blockly.Msg.BCAR_BT_READ_T3 = "BT send";
Blockly.Msg.BCAR_BT_READ_T4 = "BT input";
Blockly.Msg.BCAR_BT_READ_TOOLTIP = "Check BT read";

Blockly.Msg.BCAR_ADC_T = "Analog ADC";
Blockly.Msg.BCAR_ADC_TOOLTIP = "Read ADC";

Blockly.Msg.BCAR_DIG_T = "Read DIG pins";
Blockly.Msg.BCAR_DIG_TOOLTIP = "Read DIG pins";

Blockly.Msg.CATEGORY_ARM = "Brain_Go Arm";
Blockly.Msg.ARM = "Arm";
Blockly.Msg.ARM_HELPURL = "https://www.facebook.com/mason.chen.1420";
Blockly.Msg.ARM_INIT_TITLE = "Cat Init Setup";
Blockly.Msg.ARM_P0 = "P0";
Blockly.Msg.ARM_P1 = "P1";
Blockly.Msg.ARM_P2 = "P2";
Blockly.Msg.ARM_P3 = "P3";
Blockly.Msg.ARM_P4 = "P4";
Blockly.Msg.ARM_P5 = "P5";
Blockly.Msg.ARM_P6 = "P6";
Blockly.Msg.ARM_P7 = "P7";
Blockly.Msg.ARM_P8 = "LDM1";
Blockly.Msg.ARM_P9 = "LDM2";
Blockly.Msg.ARM_LEFT_LEG = "Left Leg";
Blockly.Msg.ARM_RIGHT_LEG = "Right Leg";
Blockly.Msg.ARM_LEFT_FOOT = "Left Foot";
Blockly.Msg.ARM_RIGHT_FOOT = "Right Foot";
Blockly.Msg.ARM_INIT_TOOLTIP = "initLegs()";
Blockly.Msg.ARM_CALIBRATE_TITLE = "Arm Calibrate Trims";
Blockly.Msg.ARM_CALIBRATE_TOOLTIP = "setTrims()";
Blockly.Msg.ARM_HOME_TITLE = "Cat Home Position";
Blockly.Msg.ARM_HOME_TOOLTIP = "home()";
Blockly.Msg.ARM_REV_TITLE = "Process data from editor";
Blockly.Msg.ARM_REV_TOOLTIP = "process_data()";
Blockly.Msg.ARM_REMOTE_TITLE = "Setup 3x10 Remote UI Name";
Blockly.Msg.ARM_REMOTE_TOOLTIP = "remote UI setup";
Blockly.Msg.ARM_DIRECTION_FORWARD = "Forward";
Blockly.Msg.ARM_DIRECTION_BACKWARD = "Backward";
Blockly.Msg.ARM_DISTANCE_UNIT = "Steps";
Blockly.Msg.ARM_DURATION_UNIT = "ms";
Blockly.Msg.ARM_TURN_L_TITLE = "turn left";
Blockly.Msg.ARM_TURN_R_TITLE = "turn right";
Blockly.Msg.ARM_FORWARD_TITLE = "forward";
Blockly.Msg.ARM_BACKWARD_TITLE = "backward";
Blockly.Msg.ARM_F_FORWARD_TITLE = "fast forward";
Blockly.Msg.ARM_F_BACKWARD_TITLE = "fast backward";
Blockly.Msg.ARM_STOP_TITLE = "stand up";
Blockly.Msg.ARM_SIT_TITLE = "sit down";
Blockly.Msg.ARM_CALIBRATE_TITLE = "calibrate";
Blockly.Msg.ARM_DIRECTION_LEFT = "Left";
Blockly.Msg.ARM_DIRECTION_RIGHT = "Right";
Blockly.Msg.ARM_TURN_L_TOOLTIP = "turn left";
Blockly.Msg.ARM_TURN_R_TOOLTIP = "turn right";
Blockly.Msg.ARM_FORWARD_TOOLTIP = "forward";
Blockly.Msg.ARM_BACKWARD_TOOLTIP = "backward";
Blockly.Msg.ARM_BASIC_M_TITLE = "Basic Motion";
Blockly.Msg.ARM_BTN_DEMO1_TITLE = "Demo 1";
Blockly.Msg.ARM_BTN_DEMO2_TITLE = "Demo 2";
Blockly.Msg.ARM_BTN_DEMO3_TITLE = "Demo 3";
Blockly.Msg.ARM_BTN_DEMO4_TITLE = "Demo 4";
Blockly.Msg.ARM_BTN_HOME_TITLE = "Home";
Blockly.Msg.ARM_BTN_F_TITLE = "Forward";
Blockly.Msg.ARM_BTN_B_TITLE = "Backward";
Blockly.Msg.ARM_BTN_L_TITLE = "Left";
Blockly.Msg.ARM_BTN_R_TITLE = "Right";
Blockly.Msg.LINKIT_WIFIUDP_TITLE = "WiFi UDP";
Blockly.Msg.LINKIT_SET_WIFI_PORT = "PORT";
Blockly.Msg.ARM_GROUP_PLAY_TITLE = "Arm Group Play";
Blockly.Msg.ARM_G_LOOP_TITLE = "Arm Group Play loop";
Blockly.Msg.ARM_SAYHI_TITLE = "Right";
Blockly.Msg.ARM_BTN_ACT1_TITLE = "Act1";
Blockly.Msg.ARM_BTN_ACT2_TITLE = "Act2";
Blockly.Msg.ARM_BTN_ACT3_TITLE = "Act3";
Blockly.Msg.ARM_BTN_ACT4_TITLE = "Act4";
Blockly.Msg.ARM_BTN_ACT5_TITLE = "Act5";
Blockly.Msg.ARM_BTN_ACT6_TITLE = "Act6";
Blockly.Msg.ARM_BTN_ACT7_TITLE = "Act7";
Blockly.Msg.ARM_BTN_ACT8_TITLE = "Act8";
Blockly.Msg.ARM_BTN_ACT9_TITLE = "Act9";
Blockly.Msg.ARM_BTN_ACT9_TITLE = "Act9";
Blockly.Msg.ARM_SET_TITLE = "設定馬達角度";
Blockly.Msg.ARM_S_NO = "馬達編號";
Blockly.Msg.ARM_ANGLE = "角度";
Blockly.Msg.ARM_MOVE_UP = "Move_up";
Blockly.Msg.ARM_MOVE_DOWN_TITLE = "Move_Down";
Blockly.Msg.ARM_L_LIMIT = "L_limit";
Blockly.Msg.ARM_MOVE_DOWN = "Move_Down";
Blockly.Msg.ARM_TM_TITLE = "Process TM data";
Blockly.Msg.ARM_TM_TOOLTIP = "Process TM data";
Blockly.Msg.ARM_MEDIAPIPE_TITLE = "Process Mediapipe data";
Blockly.Msg.ARM_MEDIAPIPE_TOOLTIP = "Process Mediapipe data";

Blockly.Msg.CATEGORY_FLIGHTCONTROLLER = "ESP8266 Flight Controller";

Blockly.Msg.LIGYRO_HELPURL = "https://github.com/ChihChuanCheng/Li-Gyro"
Blockly.Msg.SOFTAP_TITLE = "Enable Wi-Fi SoftAP mode"
Blockly.Msg.SOFTAP_SET_WIFI_SSID = "Wi-Fi ID"
Blockly.Msg.SOFTAP_SET_WIFI_PASSWORD = "Wi-Fi Password"
Blockly.Msg.SOFTAP_TOOLTIP = "Set Wi-Fi ID/Password";

Blockly.Msg.LIGYRO_MOTOR_INIT_TITLE = "Init Motors"
Blockly.Msg.LIGYRO_MOTOR_INIT_TOOLTIP = "Init Motors"

Blockly.Msg.LIGYRO_SERVO_INIT_TITLE = "Init Servos"
Blockly.Msg.LIGYRO_SERVO_INIT_TOOLTIP = "Init Servos"

Blockly.Msg.SET_LEFT_MOTOR_TITLE = "Set Left Motor"
Blockly.Msg.SET_MOTOR_NO = "Throttle";

Blockly.Msg.SET_RIGHT_MOTOR_TITLE = "Set Right Motor"

Blockly.Msg.SET_RUDDER_TITLE = "set Rudder"
Blockly.Msg.SET_RUDDER_NO = "set Rudder angle"

Blockly.Msg.SET_ELEVATOR_TITLE = "set Elevator"
Blockly.Msg.SET_ELEVATOR_NO = "set Elevator angle"

Blockly.Msg.LIGYRO_PID_CTRL_TITLE = "Wright self-stable control"
Blockly.Msg.LIGYRO_PID_CTRL_DESIRE_THROTTLE = "Player Throttle control"
Blockly.Msg.LIGYRO_PID_CTRL_DESIRE_YAW = "Player Rudder control"
Blockly.Msg.LIGYRO_PID_CTRL_WRIGHT_YAW = "Fuselage Yaw state"
Blockly.Msg.LIGYRO_PID_CTRL_YAW_P = "Rudder P parameter"
Blockly.Msg.LIGYRO_PID_CTRL_YAW_I = "Rudder I parameter"
Blockly.Msg.LIGYRO_PID_CTRL_YAW_D = "Rudder D parameter"
Blockly.Msg.LIGYRO_PID_CTRL_TOOLTIP = "input Wright self-stable PID parameters"

Blockly.Msg.LIGYRO_HOVER_PID_CTRL_TITLE = "Hovercraft self-stable control"
Blockly.Msg.LIGYRO_HOVER_PID_CTRL_DESIRE_THROTTLE = "Player Throttle control"
Blockly.Msg.LIGYRO_HOVER_PID_CTRL_DESIRE_FORWARD_BACKWARD = "Player Forward/Backward control"
Blockly.Msg.LIGYRO_HOVER_PID_CTRL_DESIRE_DIRECTION = "Player Direction control"
Blockly.Msg.LIGYRO_HOVER_PID_CTRL_TOOLTIP = "input Hovercraft self-stable PID parameters"